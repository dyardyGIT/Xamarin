﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyApp.PCL.Models
{
    public class MyProfile
    {
        public List<MyDetail> AboutInformation { get; set; }
        
        public MyProfile()
        {
            AboutInformation = new List<MyDetail>();


            AboutInformation.Add(new MyDetail { Detail = "help1" });
            AboutInformation.Add(new MyDetail { Detail = "help2" });
            AboutInformation.Add(new MyDetail { Detail = "help3" });
            AboutInformation.Add(new MyDetail { Detail = "help4" });
            AboutInformation.Add(new MyDetail { Detail = "help5" });

        }
    }

    
    public class MyDetail { 

        public string Image { get; set; }
        public string Detail { get; set; }

        public override string ToString()
        {

            return Detail;
            //return base.ToString();
        }
    }
}
